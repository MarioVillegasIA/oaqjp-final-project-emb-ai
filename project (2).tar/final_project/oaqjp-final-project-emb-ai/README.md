# Final project
# Repository for final project
mkdir final_project
from .emotion_detection import emotion_detector